package com.xinchao.translator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 씬짜오 통역: 내가 하는 한국어를 계속 듣고, 말이 끝날 때마다 베트남어로 번역해서 읽어준다.
 * 상대방의 베트남어는 버튼을 눌러 한 번 듣고 한국어로 바꿔준다.
 */
public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private static final String DEFAULT_MODEL = "claude-haiku-5-5";
    private static final Locale VI = new Locale("vi", "VN");
    private static final Locale KO = Locale.KOREA;
    private static final int REQ_MIC = 1;
    private static final int MAX_CARDS = 100;

    /** 한국어 음성 인식이 계속 듣는 자동 모드: 한국어인지, 한글로 들린 베트남어인지, 잡음인지 Claude가 판단한다. */
    private static final String SYS_AUTO =
            "You are a live interpreter between a Korean user and Vietnamese people talking face to face. "
            + "A phone's KOREAN speech recognizer is always listening, so each input is one of:\n"
            + "(a) genuine Korean speech, usually the user. It may be casual, slangy, dialectal, unpunctuated, "
            + "or contain recognition errors.\n"
            + "(b) Vietnamese speech that the Korean recognizer wrote down phonetically in Hangul, e.g. "
            + "'안 껌 쯔어' for 'Ăn cơm chưa?', '깜 언' for 'Cảm ơn', '씬 짜오' for 'Xin chào'. Such text is usually "
            + "meaningless or odd as Korean. It may also arrive as Latin-letter Vietnamese.\n"
            + "(c) not something to translate: the app's own voice being picked up (it resembles the Hangul "
            + "pronunciation of a Vietnamese translation the app recently read aloud, or repeats a recent Korean "
            + "translation), or noise.\n"
            + "Decide src = 'ko', 'vi' or 'skip'. Prefer 'ko' whenever the text makes sense as Korean. "
            + "Choose 'skip' ONLY when the input clearly matches something the app just read aloud, or is a lone "
            + "filler sound. Odd or meaningless Korean is usually Vietnamese, so when unsure between 'vi' and 'skip', "
            + "choose 'vi'.\n"
            + "If src='ko': t = natural spoken Vietnamese a local would actually say, keeping the user's tone; choose "
            + "pronouns (anh/chị/em/bạn/cô/chú/con...) from the partner info and conversation, otherwise polite "
            + "neutral forms; p = pronunciation of t written in Hangul; vi = ''.\n"
            + "If src='vi': vi = the most likely original Vietnamese sentence with full diacritics, reconstructed "
            + "from the sounds and the conversation; t = natural Korean translation of it; p = ''. Always give your "
            + "best guess; if unsure, say so briefly in n.\n"
            + "If src='skip': t, p and vi are ''.\n"
            + "n = one short note in Korean ONLY if a nuance, pronoun choice, or an uncertain guess matters; otherwise ''. "
            + "Return the result with the give_translation tool.";

    /** 대화 모드(기본): 내 한국어를 베트남어로 */
    private static final String SYS_KO_VI =
            "You are a live Korean-to-Vietnamese interpreter speaking on behalf of the user in everyday, "
            + "face-to-face conversation. The Korean comes from speech recognition, so it may be casual, "
            + "slangy, dialectal, unpunctuated, or contain recognition errors: infer what the user meant. "
            + "Translate into natural spoken Vietnamese that a Vietnamese person would actually say, keeping "
            + "the user's tone (casual or polite). Choose fitting pronouns (anh/chị/em/bạn/cô/chú/con...) from "
            + "the partner info and conversation; if unknown, use polite neutral forms. "
            + "The microphone may stay on while the app reads translations aloud, so set skip=true ONLY when the "
            + "input clearly repeats something the app just read aloud (e.g. matches the Hangul pronunciation of a "
            + "recent Vietnamese translation) or is a lone filler sound; otherwise skip=false. "
            + "Return the result with the give_translation tool.";

    private static final int MODE_AUTO = 0, MODE_KO = 1, MODE_VI = 2;

    private static final String SYS_VI_KO =
            "You are a live Vietnamese-to-Korean interpreter for a Korean user. The Vietnamese comes from "
            + "speech recognition and may lack diacritics or contain recognition errors: infer the meaning. "
            + "Translate into natural Korean that conveys the speaker's tone. "
            + "Return the result with the give_translation tool. Fields: "
            + "{\"t\":\"the Korean translation\",\"p\":\"\","
            + "\"n\":\"one short note in Korean ONLY if something is ambiguous or culturally important; otherwise empty string\","
            + "\"skip\":true only if the input is meaningless noise or just repeats a Vietnamese translation "
            + "the app recently read aloud (the app hearing itself), otherwise false}.";

    /** 앱이 최근에 소리 내어 읽은 글(번역문, 한글 발음). 마이크가 이걸 다시 들으면 번역하지 않는다. */
    private final ArrayDeque<Object[]> spokenRecently = new ArrayDeque<>();
    private static final long ECHO_WINDOW_MS = 45000;

    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsOk, viVoice, koVoice;

    /** 내 한국어를 계속 듣는 중인지 (사용자가 켠 상태) */
    private boolean continuous;
    /** 상대방 베트남어를 한 번 듣기 */
    private boolean partnerOnce;
    private boolean listening;
    private boolean speaking;
    private boolean resumed;
    private int pendingSpeech;
    private int utteranceSeq;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newFixedThreadPool(3);
    private final ArrayDeque<String> recent = new ArrayDeque<>();
    /** 읽어줄 번역 대기열. 사용자가 말하는 중이면 끝날 때까지 기다린다. */
    private final ArrayDeque<Object[]> speechQueue = new ArrayDeque<>();
    /** 지금 사용자가 말하고 있는지 (음성 인식이 말소리를 감지한 뒤 결과가 나올 때까지) */
    private boolean userTalking;
    private long userTalkingSince;
    /** 음성 인식에서 마지막으로 소식이 온 시각, 듣기를 시작한 시각 (멈춤 감지용) */
    private long lastRecognizerEvent, listenStartedAt;
    /** ‘베트남어 정확히 듣기’를 언제까지 유지할지, 이전 듣기의 늦은 신호를 언제까지 무시할지 */
    private long partnerDeadline, ignoreCallbacksUntil;

    private SharedPreferences prefs;
    private TextView status, live;
    private Button mainBtn, partnerBtn;
    private LinearLayout log;
    private ScrollView scroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("xinchao", MODE_PRIVATE);

        status = findViewById(R.id.status);
        live = findViewById(R.id.live);
        mainBtn = findViewById(R.id.mainBtn);
        partnerBtn = findViewById(R.id.partnerBtn);
        log = findViewById(R.id.log);
        scroll = findViewById(R.id.scroll);

        findViewById(R.id.settings).setOnClickListener(v -> showSettings());
        mainBtn.setOnClickListener(v -> toggleContinuous());
        partnerBtn.setOnClickListener(v -> listenPartner());

        tts = new TextToSpeech(this, this);

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("이 폰에서 음성 인식을 쓸 수 없어요. Google 앱을 설치하거나 업데이트해 주세요.");
        }
        if (apiKey().isEmpty()) {
            showSettings();
        }
        updateButtons();
    }

    // ---------------------------------------------------------------- 버튼

    private void toggleContinuous() {
        if (!continuous && !ensureReady()) return;
        continuous = !continuous;
        if (continuous) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            listenNext();
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (!partnerOnce) {
                stopRecognizer();
                live.setText("");
                setStatus("멈췄어요. 버튼을 누르면 다시 들어요.");
            }
        }
        updateButtons();
    }

    private void listenPartner() {
        if (!ensureReady()) return;
        if (partnerOnce) {
            // 한 번 더 누르면 취소
            partnerOnce = false;
            stopRecognizer();
            listenLater(200);
            updateButtons();
            return;
        }
        partnerOnce = true;
        long now = System.currentTimeMillis();
        // 상대방이 말을 시작할 때까지 최대 15초 기다린다.
        partnerDeadline = now + 15000;
        stopRecognizer();
        // 방금 끊은 한국어 듣기가 뒤늦게 보내는 신호는 무시한다.
        ignoreCallbacksUntil = now + 550;
        if (tts != null) tts.stop();
        speechQueue.clear();
        pendingSpeech = 0;
        speaking = false;
        live.setText("");
        setStatus("상대방 말을 듣는 중… 베트남어로 말하게 하세요");
        updateButtons();
        listenLater(600);
    }

    private boolean ensureReady() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return false;
        }
        if (apiKey().isEmpty()) {
            showSettings();
            return false;
        }
        if (recognizer == null) {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                toast("이 폰에서 음성 인식을 쓸 수 없어요. Google 앱을 설치하거나 업데이트해 주세요.");
                return false;
            }
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(listener);
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_MIC) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            setStatus("마이크가 허용됐어요. ‘계속 듣기 시작’을 눌러주세요.");
        } else {
            setStatus("마이크를 허용해야 말을 들을 수 있어요. 폰 설정 > 애플리케이션 > 씬짜오 통역 > 권한에서 켜주세요.");
        }
    }

    private void updateButtons() {
        mainBtn.setActivated(continuous);
        mainBtn.setText(continuous ? "■ 듣기 멈추기" : "● 계속 듣기 시작");
        partnerBtn.setActivated(partnerOnce);
        partnerBtn.setTextColor(getColor(partnerOnce ? R.color.on_accent : R.color.jade));
        partnerBtn.setText(partnerOnce ? "상대방 말 듣는 중… (누르면 취소)" : "상대방 말 듣기 (베트남어 → 한국어)");
    }

    // ---------------------------------------------------------------- 음성 인식

    private void listenNext() {
        if (!resumed || speaking || listening || recognizer == null) return;
        String lang;
        if (partnerOnce) {
            lang = "vi-VN";
        } else if (continuous) {
            lang = "ko-KR";
        } else {
            updateButtons();
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L);
        if (!partnerOnce && autoDetect() && Build.VERSION.SDK_INT >= 34) {
            // 안드로이드 14 이상: 폰이 지원하면 한국어·베트남어를 스스로 바꿔 가며 알아듣게 한다.
            // 지원하지 않는 폰에서는 무시되고, 그때는 Claude가 한글로 적힌 베트남어를 알아본다.
            ArrayList<String> both = new ArrayList<>();
            both.add("ko-KR");
            both.add("vi-VN");
            i.putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true);
            i.putStringArrayListExtra("android.speech.extra.LANGUAGE_DETECTION_ALLOWED_LANGUAGES", both);
            i.putExtra("android.speech.extra.ENABLE_LANGUAGE_SWITCH", "high_precision");
            i.putStringArrayListExtra("android.speech.extra.LANGUAGE_SWITCH_ALLOWED_LANGUAGES", both);
        }
        listening = true;
        listenStartedAt = lastRecognizerEvent = System.currentTimeMillis();
        try {
            recognizer.startListening(i);
        } catch (Exception e) {
            listening = false;
            setStatus("음성 인식을 시작하지 못했어요. 다시 눌러주세요.");
            return;
        }
        setStatus(partnerOnce ? "상대방 말을 듣는 중… 베트남어로 말하게 하세요"
                : autoDetect() ? "듣는 중… 한국어·베트남어 모두 알아서 번역해요"
                : "듣는 중… 한국어로 편하게 말하세요");
        updateButtons();
    }

    private void beat() {
        lastRecognizerEvent = System.currentTimeMillis();
    }

    /**
     * 폰 음성 인식이 아무 응답 없이 멈추는 경우가 있다(특히 앱이 소리를 내는 중).
     * 2초마다 살펴보고, 말하는 중이 아닌데 12초 넘게 소식이 없거나 1분 넘게 결과가 없으면 다시 듣기 시작한다.
     */
    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            boolean silentTooLong = now - lastRecognizerEvent > 12000 && !userTalking;
            boolean stuckTooLong = now - listenStartedAt > 60000;
            if (resumed && listening && (silentTooLong || stuckTooLong)) {
                stopRecognizer();
                userTalking = false;
                live.setText("");
                flushSpeech();
                listenLater(200);
            } else if (resumed && !listening && !speaking && (continuous || partnerOnce)) {
                // 듣고 있어야 하는데 쉬고 있으면 다시 시작
                listenNext();
            }
            ui.postDelayed(this, 2000);
        }
    };

    private void listenLater(long ms) {
        ui.postDelayed(this::listenNext, ms);
    }

    private void stopRecognizer() {
        if (recognizer != null) {
            try {
                recognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        listening = false;
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) { beat(); }
        @Override public void onBeginningOfSpeech() { beat(); userTalking = true; userTalkingSince = System.currentTimeMillis(); }
        @Override public void onRmsChanged(float rmsdB) { beat(); }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { beat(); }
        @Override public void onEvent(int eventType, Bundle params) { }

        @Override
        public void onPartialResults(Bundle partial) {
            beat();
            String s = firstResult(partial);
            if (s != null && !s.isEmpty()) live.setText(s);
        }

        @Override
        public void onResults(Bundle results) {
            if (System.currentTimeMillis() < ignoreCallbacksUntil) return;
            listening = false;
            userTalking = false;
            boolean fromPartner = partnerOnce;
            partnerOnce = false;
            String s = firstResult(results);
            live.setText("");
            if (s != null && !s.trim().isEmpty() && isEcho(s)) {
                // 앱이 방금 읽은 소리를 다시 들은 것: 번역하지 않는다.
                s = null;
            }
            if (s != null && !s.trim().isEmpty()) {
                translate(s.trim(), !fromPartner);
            } else if (fromPartner && System.currentTimeMillis() < partnerDeadline) {
                // 아직 아무 말도 못 들었으면 계속 베트남어로 듣는다.
                partnerOnce = true;
            } else if (fromPartner) {
                setStatus("상대방 말을 알아듣지 못했어요. 다시 눌러주세요.");
            }
            if (!continuous && !fromPartner) setStatus("대기 중이에요");
            if (!continuous && fromPartner && !partnerOnce) setStatus("대기 중이에요. ‘계속 듣기 시작’을 누르면 내 말을 들어요.");
            updateButtons();
            flushSpeech();
            listenLater(150);
        }

        @Override
        public void onError(int error) {
            if (System.currentTimeMillis() < ignoreCallbacksUntil) return;
            listening = false;
            userTalking = false;
            long delay = 300;
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                continuous = false;
                partnerOnce = false;
                setStatus("마이크 권한이 없어요. 폰 설정에서 마이크를 허용해 주세요.");
                updateButtons();
                return;
            }
            if (partnerOnce && (error == SpeechRecognizer.ERROR_NO_MATCH
                    || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    || error == SpeechRecognizer.ERROR_CLIENT)) {
                if (System.currentTimeMillis() < partnerDeadline) {
                    // 아직 기다리는 중: 끄지 않고 다시 베트남어로 듣는다.
                    delay = 250;
                } else {
                    partnerOnce = false;
                    setStatus("상대방 말이 들리지 않았어요. 다시 눌러주세요.");
                }
            }
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                stopRecognizer();
                delay = 800;
            }
            if (error == SpeechRecognizer.ERROR_NETWORK
                    || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                    || error == SpeechRecognizer.ERROR_SERVER) {
                setStatus("인터넷 연결을 확인하는 중…");
                delay = 2000;
            }
            updateButtons();
            flushSpeech();
            listenLater(delay);
        }
    };

    private static String firstResult(Bundle b) {
        if (b == null) return null;
        ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (list == null || list.isEmpty()) ? null : list.get(0);
    }

    // ---------------------------------------------------------------- 번역

    /**
     * @param fromKoRecognizer true: 한국어 음성 인식(자동 모드)에서 온 글. 한국어인지 한글로 들린 베트남어인지 Claude가 판단한다.
     *                         false: 베트남어 음성 인식(‘베트남어 정확히 듣기’)에서 온 글.
     */
    private void translate(String text, boolean fromKoRecognizer) {
        translate(text, fromKoRecognizer, false);
    }

    private void translate(String text, boolean fromKoRecognizer, boolean forceVi) {
        View empty = findViewById(R.id.empty);
        if (empty != null) log.removeView(empty);

        // 폰이 언어를 스스로 바꿔 베트남어를 로마자로 적어 준 경우에는 바로 베트남어로 다룬다.
        final int mode = !fromKoRecognizer ? MODE_VI
                : autoDetect() ? (hangulRatio(text) >= 0.3 ? MODE_AUTO : MODE_VI)
                : MODE_KO;
        final boolean auto = mode == MODE_AUTO;

        View card = getLayoutInflater().inflate(R.layout.item_card, log, false);
        TextView who = card.findViewById(R.id.who);
        TextView src = card.findViewById(R.id.src);
        TextView dst = card.findViewById(R.id.dst);
        TextView pron = card.findViewById(R.id.pron);
        TextView note = card.findViewById(R.id.note);
        who.setText(auto ? "언어 확인 중…" : mode == MODE_KO ? "나 · 한국어 → 베트남어" : "상대방 · 베트남어 → 한국어");
        src.setText(text);
        dst.setText("번역 중…");
        dst.setTextColor(getColor(R.color.muted));
        log.addView(card);
        while (log.getChildCount() > MAX_CARDS) log.removeViewAt(0);
        scrollToEnd();

        final String key = apiKey();
        final String model = prefs.getString("model", DEFAULT_MODEL).trim();
        final String about = prefs.getString("about", "").trim();
        final String context = String.join("\n", recent);

        net.execute(() -> {
            try {
                JSONObject r = callClaude(key, model.isEmpty() ? DEFAULT_MODEL : model, text, mode, forceVi, context, about);
                final String t = r.optString("t", "").trim();
                final String p = r.optString("p", "").trim();
                final String n = r.optString("n", "").trim();
                final String viGuess = r.optString("vi", "").trim();
                if (r.optBoolean("_failed", false)) throw new IOException("번역 결과를 읽지 못했어요.");
                String srcLang = auto ? r.optString("src", "ko").trim() : mode == MODE_KO ? "ko" : "vi";
                if (r.optBoolean("skip", false) || t.isEmpty()) srcLang = "skip";
                final String lang = srcLang;
                ui.post(() -> {
                    if ("skip".equals(lang)) {
                        // 앱 자기 목소리나 잡음으로 판단: 읽지 않고 작게만 남긴다. 누르면 베트남어로 보고 번역한다.
                        who.setText("건너뜀 · 앱 소리나 잡음으로 판단 (누르면 베트남어로 번역)");
                        dst.setVisibility(View.GONE);
                        card.setAlpha(0.6f);
                        card.setOnClickListener(v -> {
                            log.removeView(card);
                            translate(text, fromKoRecognizer, true);
                        });
                        return;
                    }
                    final boolean isKorean = "ko".equals(lang);
                    dst.setText(t);
                    dst.setTextColor(getColor(R.color.fg));
                    if (isKorean) {
                        who.setText("나 · 한국어 → 베트남어");
                        if (!p.isEmpty()) {
                            pron.setText("발음  " + p);
                            pron.setVisibility(View.VISIBLE);
                        }
                    } else if (auto) {
                        // 한국어 인식기가 한글로 적은 베트남어: Claude가 원래 문장을 추정했다.
                        who.setText("상대방 · 베트남어 → 한국어 (소리로 추정)");
                        src.setText((viGuess.isEmpty() ? "" : viGuess + "\n") + "들린 소리: " + text);
                    } else {
                        who.setText("상대방 · 베트남어 → 한국어");
                    }
                    if (!n.isEmpty()) {
                        note.setText(n);
                        note.setVisibility(View.VISIBLE);
                    }
                    final Locale out = isKorean ? VI : KO;
                    card.setOnClickListener(v -> speak(t, out));
                    if (isKorean) {
                        remember("User (Korean): " + text + " => " + t
                                + (p.isEmpty() ? "" : "  [app read this aloud; Hangul pronunciation: " + p + "]"));
                        addSpoken(p);
                    } else {
                        remember("Partner (Vietnamese): " + (viGuess.isEmpty() ? text : viGuess) + " => " + t
                                + "  [app read the Korean aloud]");
                    }
                    scrollToEnd();
                    if (isKorean || prefs.getBoolean("readKorean", true)) speak(t, out);
                });
            } catch (Exception e) {
                final String msg = friendlyError(e);
                ui.post(() -> {
                    if (auto) who.setText("번역 실패");
                    dst.setText(msg + "\n(카드를 누르면 다시 번역해요)");
                    dst.setTextColor(getColor(R.color.error));
                    card.setOnClickListener(v -> {
                        log.removeView(card);
                        translate(text, fromKoRecognizer, forceVi);
                    });
                    scrollToEnd();
                });
            }
        });
    }

    /** 글자 중 한글 비율 (공백·문장부호 제외) */
    static double hangulRatio(String s) {
        int hangul = 0, letters = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0xAC00 && ch <= 0xD7A3) {
                hangul++;
                letters++;
            } else if (Character.isLetter(ch)) {
                letters++;
            }
        }
        return letters == 0 ? 1.0 : (double) hangul / letters;
    }

    // ---------------------------------------------------------------- 앱 자기 목소리 거르기

    private void addSpoken(String s) {
        if (s == null || s.trim().isEmpty()) return;
        long now = System.currentTimeMillis();
        spokenRecently.addLast(new Object[]{bigrams(s), now});
        while (spokenRecently.size() > 12) spokenRecently.removeFirst();
    }

    /** 마이크로 들린 글이 앱이 최근 읽은 글과 거의 같으면 true */
    private boolean isEcho(String heard) {
        java.util.Set<String> h = bigrams(heard);
        if (h.size() < 3) return false;
        long now = System.currentTimeMillis();
        for (Object[] item : spokenRecently) {
            if (now - (Long) item[1] > ECHO_WINDOW_MS) continue;
            @SuppressWarnings("unchecked")
            java.util.Set<String> said = (java.util.Set<String>) item[0];
            if (echoScore(h, said) >= 0.6) return true;
        }
        return false;
    }

    static double echoScore(java.util.Set<String> heard, java.util.Set<String> said) {
        if (heard.isEmpty()) return 0;
        int hit = 0;
        for (String g : heard) if (said.contains(g)) hit++;
        return (double) hit / heard.size();
    }

    /** 성조·띄어쓰기·문장부호를 없앤 뒤 두 글자씩 묶은 집합 */
    static java.util.Set<String> bigrams(String s) {
        String n = java.text.Normalizer.normalize(s.toLowerCase(Locale.ROOT), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .replace('đ', 'd')
                .replaceAll("[^\\p{L}\\p{N}]", "");
        java.util.Set<String> out = new java.util.HashSet<>();
        for (int i = 0; i + 1 < n.length(); i++) out.add(n.substring(i, i + 2));
        return out;
    }

    private void remember(String line) {
        recent.addLast(line);
        while (recent.size() > 6) recent.removeFirst();
    }

    private JSONObject callClaude(String key, String model, String text, int mode, boolean forceVi,
                                  String context, String about) throws Exception {
        StringBuilder user = new StringBuilder();
        if (!about.isEmpty()) {
            user.append("About the conversation partner: ").append(about).append("\n");
        }
        if (!context.isEmpty()) {
            user.append("Recent conversation (context only, do not translate):\n").append(context).append("\n\n");
        }
        if (forceVi) {
            user.append("The user confirmed this is real Vietnamese speech that the Korean recognizer wrote in "
                    + "Hangul. src must be 'vi'. Reconstruct the Vietnamese and translate it.\n");
        }
        user.append(mode == MODE_AUTO ? "Heard by the Korean recognizer: "
                : mode == MODE_KO ? "Translate this Korean: " : "Translate this Vietnamese: ").append(text);

        JSONObject message = new JSONObject();
        message.put("role", "user");
        message.put("content", user.toString());
        JSONArray messages = new JSONArray();
        messages.put(message);

        // 답을 항상 정해진 모양으로 받도록 "도구" 형식을 강제한다.
        JSONObject props = new JSONObject();
        JSONArray required = new JSONArray();
        if (mode == MODE_AUTO) {
            props.put("src", new JSONObject().put("type", "string")
                    .put("enum", new JSONArray().put("ko").put("vi").put("skip"))
                    .put("description", "ko = Korean speech, vi = Vietnamese heard as Hangul, skip = app's own voice or noise"));
            props.put("vi", new JSONObject().put("type", "string").put("description",
                    "if src=vi: the reconstructed original Vietnamese with diacritics, else empty"));
            props.put("t", new JSONObject().put("type", "string").put("description",
                    "src=ko: Vietnamese translation; src=vi: Korean translation; skip: empty"));
            props.put("p", new JSONObject().put("type", "string").put("description",
                    "src=ko: pronunciation of the Vietnamese translation in Hangul, else empty"));
            required.put("src").put("vi").put("t").put("p").put("n");
        } else if (mode == MODE_KO) {
            props.put("t", new JSONObject().put("type", "string").put("description", "the Vietnamese translation"));
            props.put("p", new JSONObject().put("type", "string").put("description",
                    "pronunciation of the Vietnamese translation written in Korean Hangul"));
            props.put("skip", new JSONObject().put("type", "boolean").put("description",
                    "true only when the input repeats what the app just read aloud, or is a lone filler sound"));
            required.put("t").put("p").put("n").put("skip");
        } else {
            props.put("t", new JSONObject().put("type", "string").put("description", "the Korean translation"));
            props.put("p", new JSONObject().put("type", "string").put("description", "empty string"));
            props.put("skip", new JSONObject().put("type", "boolean").put("description",
                    "true only for noise or the app's own voice"));
            required.put("t").put("p").put("n").put("skip");
        }
        props.put("n", new JSONObject().put("type", "string").put("description",
                "short Korean note only if important, otherwise empty string"));
        JSONObject schema = new JSONObject();
        schema.put("type", "object");
        schema.put("properties", props);
        schema.put("required", required);
        JSONObject tool = new JSONObject();
        tool.put("name", "give_translation");
        tool.put("description", "Return the translation result.");
        tool.put("input_schema", schema);
        JSONObject choice = new JSONObject();
        choice.put("type", "tool");
        choice.put("name", "give_translation");

        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("max_tokens", 1000);
        body.put("system", mode == MODE_AUTO ? SYS_AUTO : mode == MODE_KO ? SYS_KO_VI : SYS_VI_KO);
        body.put("messages", messages);
        body.put("tools", new JSONArray().put(tool));
        body.put("tool_choice", choice);

        HttpURLConnection c = (HttpURLConnection) new URL("https://api.anthropic.com/v1/messages").openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(10000);
            c.setReadTimeout(20000);
            c.setDoOutput(true);
            c.setRequestProperty("content-type", "application/json");
            c.setRequestProperty("x-api-key", key);
            c.setRequestProperty("anthropic-version", "2023-06-01");
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            String resp = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code >= 400) throw new IOException(apiError(code, resp, model));

            JSONArray content = new JSONObject(resp).getJSONArray("content");
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < content.length(); i++) {
                JSONObject block = content.getJSONObject(i);
                String type = block.optString("type");
                if ("tool_use".equals(type)) {
                    JSONObject input = block.optJSONObject("input");
                    if (input != null) return input;
                } else if ("text".equals(type)) {
                    out.append(block.optString("text"));
                }
            }
            return parseLoose(out.toString());
        } finally {
            c.disconnect();
        }
    }

    /** 형식이 깨진 답에서도 번역문(t), 발음(p), 메모(n)만 골라낸다. 날것의 JSON은 화면에 보이지 않게 한다. */
    static JSONObject parseLoose(String s) throws JSONException {
        int a = s.indexOf('{');
        int z = s.lastIndexOf('}');
        if (a >= 0 && z > a) {
            try {
                JSONObject j = new JSONObject(s.substring(a, z + 1));
                if (!j.optString("t", "").trim().isEmpty()) return j;
            } catch (JSONException ignored) {
            }
        }
        JSONObject r = new JSONObject();
        String t = field(s, "t");
        if (t == null) {
            // JSON 모양이 아니면 글 전체를 번역문으로 본다.
            t = s.contains("\"t\"") ? "" : s.trim();
        }
        r.put("t", t);
        if (t.isEmpty()) r.put("_failed", true);
        String p = field(s, "p");
        String n = field(s, "n");
        r.put("p", p == null ? "" : p);
        r.put("n", n == null ? "" : n);
        return r;
    }

    private static String field(String s, String name) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("\"" + name + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)(\"|$)")
                .matcher(s);
        if (!m.find()) return null;
        return m.group(1).replace("\\n", " ").replace("\\\"", "\"").replace("\\\\", "\\").trim();
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private static String apiError(int code, String resp, String model) {
        String detail = "";
        try {
            detail = new JSONObject(resp).getJSONObject("error").optString("message", "");
        } catch (Exception ignored) {
        }
        String lower = detail.toLowerCase(Locale.ROOT);
        if (code == 401) return "API 키가 맞지 않아요. ‘설정’에서 키를 다시 확인해 주세요.";
        if (lower.contains("credit") || lower.contains("billing")) {
            return "API 크레딧이 부족해요. console.anthropic.com 에서 충전해 주세요.";
        }
        if (code == 404 || lower.contains("model")) {
            return "번역 모델(" + model + ")을 찾을 수 없어요. ‘설정’에서 모델 이름을 확인해 주세요.";
        }
        if (code == 429) return "요청이 너무 많아요. 잠시 후 다시 시도해 주세요.";
        if (code >= 500) return "번역 서버가 바빠요. 잠시 후 다시 시도해 주세요.";
        return "번역 오류(" + code + "): " + detail;
    }

    private static String friendlyError(Exception e) {
        if (e instanceof UnknownHostException) return "인터넷에 연결되어 있지 않아요.";
        if (e instanceof SocketTimeoutException) return "응답이 너무 늦어요. 다시 시도해 주세요.";
        String m = e.getMessage();
        return (m == null || m.isEmpty()) ? "번역하지 못했어요." : m;
    }

    // ---------------------------------------------------------------- 음성 출력

    @Override
    public void onInit(int st) {
        if (st != TextToSpeech.SUCCESS) {
            setStatus("음성 출력 기능을 쓸 수 없어요. 번역 글자를 상대방에게 보여주세요.");
            return;
        }
        ttsOk = true;
        viVoice = tts.isLanguageAvailable(VI) >= TextToSpeech.LANG_AVAILABLE;
        koVoice = tts.isLanguageAvailable(KO) >= TextToSpeech.LANG_AVAILABLE;
        tts.setSpeechRate(0.95f);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { ui.post(MainActivity.this::speechFinished); }
            @Override public void onError(String id) { ui.post(MainActivity.this::speechFinished); }
            @Override public void onStop(String id, boolean interrupted) { ui.post(MainActivity.this::speechFinished); }
        });
        if (!viVoice) showVoiceNotice();
    }

    private void speak(String text, Locale loc) {
        if (!ttsOk || text == null || text.isEmpty()) return;
        boolean available = loc.equals(VI) ? viVoice : koVoice;
        if (!available) {
            if (loc.equals(VI)) toast("베트남어 음성이 설치돼 있지 않아 소리를 낼 수 없어요. 화면을 보여주세요.");
            return;
        }
        addSpoken(text);
        speechQueue.addLast(new Object[]{text, loc});
        flushSpeech();
    }

    /**
     * 대기 중인 번역을 읽는다. 사용자가 말하는 중이면 말을 끊지 않도록 결과가 나올 때까지 기다린다.
     * 읽는 동안에는 마이크를 잠시 멈춰, 앱이 자기 목소리를 다시 번역하지 않게 한다.
     */
    private void flushSpeech() {
        if (speechQueue.isEmpty() || !ttsOk) return;
        boolean waitForUser = userTalking && System.currentTimeMillis() - userTalkingSince < 4000;
        if (waitForUser || (partnerOnce && listening)) {
            ui.postDelayed(this::flushSpeech, 500);
            if (userTalking) setStatus("말씀이 끝나면 번역을 읽어줄게요…");
            return;
        }
        if (listenWhileSpeaking()) {
            // 읽는 동안에도 마이크를 켜 둔다. 앱 자기 목소리는 번역 단계에서 걸러낸다.
            setStatus("번역을 읽는 중… 계속 듣고 있어요");
        } else {
            speaking = true;
            stopRecognizer();
            live.setText("");
            setStatus("번역을 읽는 중… 끝나면 다시 들어요");
        }
        while (!speechQueue.isEmpty()) {
            Object[] item = speechQueue.pollFirst();
            pendingSpeech++;
            tts.setLanguage((Locale) item[1]);
            tts.speak((String) item[0], TextToSpeech.QUEUE_ADD, null, "u" + (utteranceSeq++));
        }
    }

    private void speechFinished() {
        pendingSpeech = Math.max(0, pendingSpeech - 1);
        if (pendingSpeech == 0) {
            speaking = false;
            if (!continuous && !partnerOnce) setStatus("대기 중이에요");
            listenLater(250);
        }
    }

    private void showVoiceNotice() {
        new AlertDialog.Builder(this)
                .setTitle("베트남어 음성이 없어요")
                .setMessage("번역은 되지만 베트남어를 소리 내어 읽으려면 음성 데이터가 필요해요.\n\n"
                        + "폰 설정 > 일반 > 텍스트 음성 변환(TTS)에서 ‘Google 음성 엔진’을 고르고, "
                        + "언어에서 베트남어(Tiếng Việt) 음성을 내려받아 주세요. 그다음 앱을 다시 켜면 돼요.")
                .setPositiveButton("TTS 설정 열기", (d, w) -> {
                    try {
                        startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                    } catch (Exception e) {
                        try {
                            startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
                        } catch (Exception e2) {
                            toast("설정 화면을 열지 못했어요. 폰 설정에서 ‘텍스트 음성 변환’을 검색해 주세요.");
                        }
                    }
                })
                .setNegativeButton("나중에", null)
                .show();
    }

    // ---------------------------------------------------------------- 설정

    private boolean autoDetect() {
        return prefs.getBoolean("autoDetect", false);
    }

    private boolean listenWhileSpeaking() {
        return prefs.getBoolean("overlap", true);
    }

    private String apiKey() {
        return prefs.getString("key", "").trim();
    }

    private void showSettings() {
        int pad = dp(20);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, dp(8), pad, 0);

        TextView help = new TextView(this);
        help.setText("Claude API 키를 넣어주세요. console.anthropic.com > API Keys 에서 만들 수 있어요. "
                + "키는 이 폰에만 저장돼요.");
        help.setTextColor(getColor(R.color.muted));
        box.addView(help);

        EditText key = new EditText(this);
        key.setHint("sk-ant-...");
        key.setSingleLine(true);
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        key.setText(apiKey());
        box.addView(key);

        TextView aboutLabel = new TextView(this);
        aboutLabel.setText("\n대화 상대 (선택) — 호칭과 말투를 맞추는 데 써요");
        aboutLabel.setTextColor(getColor(R.color.muted));
        box.addView(aboutLabel);

        EditText about = new EditText(this);
        about.setHint("예: 베트남인 아내, 20대 / 가게 손님 / 시어머니");
        about.setText(prefs.getString("about", ""));
        box.addView(about);

        TextView modelLabel = new TextView(this);
        modelLabel.setText("\n번역 모델 (보통은 그대로 두세요)");
        modelLabel.setTextColor(getColor(R.color.muted));
        box.addView(modelLabel);

        EditText model = new EditText(this);
        model.setSingleLine(true);
        model.setText(prefs.getString("model", DEFAULT_MODEL));
        box.addView(model);

        CheckBox overlap = new CheckBox(this);
        overlap.setText("번역을 읽는 동안에도 계속 듣기\n(이어폰을 끼면 앱 소리가 섞이지 않아 더 정확해요)");
        overlap.setChecked(listenWhileSpeaking());
        overlap.setPadding(0, dp(12), 0, 0);
        box.addView(overlap);

        CheckBox readKo = new CheckBox(this);
        readKo.setText("상대방 말의 한국어 번역도 소리 내어 읽기");
        readKo.setChecked(prefs.getBoolean("readKorean", true));
        box.addView(readKo);

        CheckBox autoBox = new CheckBox(this);
        autoBox.setText("한국어·베트남어 자동 구분 (실험)\n끄면 대화 모드: 내 말은 계속 듣고, 상대방 말은 버튼으로 들어요");
        autoBox.setChecked(autoDetect());
        box.addView(autoBox);

        ScrollView wrap = new ScrollView(this);
        wrap.addView(box);

        new AlertDialog.Builder(this)
                .setTitle("설정")
                .setView(wrap)
                .setPositiveButton("저장", (d, w) -> {
                    prefs.edit()
                            .putString("key", key.getText().toString().trim())
                            .putString("about", about.getText().toString().trim())
                            .putString("model", model.getText().toString().trim())
                            .putBoolean("overlap", overlap.isChecked())
                            .putBoolean("readKorean", readKo.isChecked())
                            .putBoolean("autoDetect", autoBox.isChecked())
                            .apply();
                    toast(apiKey().isEmpty() ? "API 키가 없으면 번역할 수 없어요." : "저장했어요.");
                })
                .setNegativeButton("닫기", null)
                .show();
    }

    // ---------------------------------------------------------------- 생명주기

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        listenLater(300);
        ui.removeCallbacks(watchdog);
        ui.postDelayed(watchdog, 2000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        ui.removeCallbacks(watchdog);
        stopRecognizer();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        net.shutdownNow();
    }

    // ---------------------------------------------------------------- 도우미

    private void setStatus(String s) {
        status.setText(s);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private void scrollToEnd() {
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
